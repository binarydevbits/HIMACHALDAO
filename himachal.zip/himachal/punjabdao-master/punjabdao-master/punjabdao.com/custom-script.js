// Custom JavaScript for Modern Interactions

(function($) {
    "use strict";
    
    $(document).ready(function() {
        
        // Smooth scrolling for anchor links
        $('a[href^="#"]').on('click', function(e) {
            e.preventDefault();
            
            var target = this.hash;
            var $target = $(target);
            
            $('html, body').animate({
                'scrollTop': $target.offset().top - 80
            }, 800, 'swing');
        });
        
        // Add active class to menu items on scroll
        $(window).on('scroll', function() {
            // Header shrink on scroll
            if ($(window).scrollTop() > 100) {
                $('.header').addClass('header-shrink');
            } else {
                $('.header').removeClass('header-shrink');
            }
            
            // Back to top button visibility
            if ($(this).scrollTop() > 300) {
                $('.back-to-top').addClass('visible');
            } else {
                $('.back-to-top').removeClass('visible');
            }
        });
        
        // Add animations to elements when they come into view
        $('.single-header-top-content').addClass('wow fadeInUp');
        $('.vc_custom_heading').addClass('wow fadeInUp');
        $('.wpb_single_image').addClass('wow fadeIn');
        $('.envira-gallery-item').addClass('wow fadeIn');
        
        // Initialize WOW.js for animations
        if (typeof WOW === 'function') {
            new WOW({
                boxClass: 'wow',
                animateClass: 'animated',
                offset: 100,
                mobile: true,
                live: true
            }).init();
        }
        
        // Add back to top button
        $('body').append('<a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>');
        
        // Back to top button click
        $('.back-to-top').on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
        
        // Add hover effect to navigation
        $('.navbar-nav > li').hover(
            function() {
                $(this).addClass('nav-hover');
            }, 
            function() {
                $(this).removeClass('nav-hover');
            }
        );
        
        // Make gallery images appear with a fade-in effect
        $('.envira-gallery-image').each(function() {
            var $img = $(this);
            $img.attr('data-src', $img.attr('src'));
            $img.attr('src', '');
            
            $img.on('load', function() {
                $(this).fadeIn(300);
            });
            
            if ($img.complete) {
                $img.trigger('load');
            }
        });
        
        // Mobile menu enhancements
        $('.mobile-nav-toggler').on('click', function() {
            $(this).toggleClass('active');
            $('.navbar-collapse').slideToggle(300);
        });
        
    });
    
    // Preloader
    $(window).on('load', function() {
        $('body').addClass('page-loaded');
    });
    
})(jQuery); 